from django.contrib import admin
from service.models import Service

# Register your models here.
admin.site.register(Service)